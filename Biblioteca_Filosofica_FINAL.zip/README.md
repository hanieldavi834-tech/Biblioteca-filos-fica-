# Biblioteca Filosófica — versão final

Site com 16 autores e 334 obras.

Última atualização:
- Franz Kafka: Diários; Cartas a Milena; Carta ao Pai.
- Liev Tolstói: Juventude; O Evangelho em Breve; O Diabo; Patriotismo e Governo.
- Albert Camus: Cartas a um Amigo Alemão; Reflexões sobre a Guilhotina.
- Jean-Jacques Rousseau: Carta a d'Alembert sobre os Espetáculos.
- Immanuel Kant: Em Que Consiste Orientar-se no Pensamento?; O Conflito das Faculdades.

O restante do site foi mantido.
